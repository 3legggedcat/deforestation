\
    using Godot;
    using System;

    public partial class Enemy : CharacterBody2D
    {
        [Export] public int Speed { get; set; } = 120;
        private NavigationAgent2D agent;
        private Node2D player;

        public override void _Ready()
        {
            agent = GetNode<NavigationAgent2D>("NavigationAgent2D");
            // Player will be instanced under /root/Main/Player in Main.tscn
            player = GetTree().Root.GetNode<Node2D>("Main/Player");
        }

        public override void _PhysicsProcess(double delta)
        {
            if (player == null || agent == null) return;

            agent.TargetPosition = player.GlobalPosition;
            Vector2 next = agent.GetNextPathPosition();
            Vector2 dir = (next - GlobalPosition).Normalized();
            Velocity = dir * Speed;
            MoveAndSlide();
        }
    }
