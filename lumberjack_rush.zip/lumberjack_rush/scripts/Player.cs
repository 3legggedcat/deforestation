\
    using Godot;
    using System;

    public partial class Player : CharacterBody2D
    {
        [Export] public int Speed { get; set; } = 200;

        private AnimatedSprite2D anim;
        private Particles2D chopParticles;
        private CanvasLayer uiLayer;
        private Label scoreLabel;
        private int score = 0;

        public override void _Ready()
        {
            anim = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
            chopParticles = GetNode<Particles2D>("ChopParticles");
            uiLayer = GetTree().Root.GetNode<CanvasLayer>("UI");
            scoreLabel = uiLayer.GetNode<Label>("ScoreLabel");
            // Ensure initial UI text
            scoreLabel.Text = $"Logs: {score}";
        }

        public override void _PhysicsProcess(double delta)
        {
            Vector2 input = Input.GetVector("ui_left", "ui_right", "ui_up", "ui_down");
            Velocity = input * Speed;
            MoveAndSlide();

            if (input.Length() > 0.01f)
                anim.Play("walk");
            else
                anim.Play("idle");
        }

        // Called by Log Area2D when picked up
        public void AddScore(int amount)
        {
            score += amount;
            if (scoreLabel != null)
                scoreLabel.Text = $"Logs: {score}";
            if (chopParticles != null)
            {
                chopParticles.Emitting = false;
                chopParticles.Emitting = true;
            }
        }
    }
