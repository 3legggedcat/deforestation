\
    using Godot;
    using System;

    public partial class Log : Area2D
    {
        [Export] public int Value { get; set; } = 1;
        private Particles2D pickupBurst;

        public override void _Ready()
        {
            pickupBurst = GetNode<Particles2D>("PickupBurst");
            Connect("body_entered", new Callable(this, nameof(OnBodyEntered)));
        }

        public void OnBodyEntered(Node body)
        {
            if (body is Player player)
            {
                // give points
                player.AddScore(Value);
                if (pickupBurst != null)
                {
                    pickupBurst.Emitting = true;
                }
                // Queue free after short delay to allow particles to play
                CallDeferred(nameof(DeferredFree));
            }
        }

        private void DeferredFree()
        {
            QueueFree();
        }
    }
