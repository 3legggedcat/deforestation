# Lumberjack Rush

A simple top-down 2D Godot 4.4 game built with C#.

## Controls
- Move: WASD or Arrow Keys

## How to use
1. Download and unzip the project.
2. Open Godot 4.4 and select the project folder.
3. Open `scenes/Main.tscn` and run the scene.

## Notes
- This package contains minimal example scenes and scripts to satisfy the assignment requirements.
- You may need to add simple sprite/tileset assets in `assets/sprites/` and configure `tilesets/ForestTileset.tres` in the Godot editor.
