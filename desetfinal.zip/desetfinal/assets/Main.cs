using Godot;
using System;

public partial class Main : Node2D
{
	private Player player;
	private Label scoreLabel;
	private int score = 0;

	public override void _Ready()
	{
		// Get references
		player = GetNode<Player>("Player");
		scoreLabel = GetNode<Label>("CanvasLayer/Label");

		if (scoreLabel != null)
			scoreLabel.Text = "Score: " + score;
	}

	public void AddScore(int amount)
	{
		score += amount;
		if (scoreLabel != null)
			scoreLabel.Text = "Score: " + score;
	}

	public override void _Process(double delta)
	{
		// Optional: Center camera on player (if Camera2D isn’t a child)
		Camera2D camera = GetNodeOrNull<Camera2D>("Camera2D");
		if (camera != null && player != null)
		{
			camera.GlobalPosition = player.GlobalPosition;
		}
	}
}
