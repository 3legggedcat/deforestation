using Godot;
using System;

public partial class Player : CharacterBody2D
{
	[Export] public float Speed = 200.0f;

	private GPUParticles2D trailDust;
	private Sprite2D sprite;

	public override void _Ready()
	{
		// Ensure player renders above tilemap
		ZIndex = 1;

		// Get nodes (names must match exactly)
		trailDust = GetNode<GPUParticles2D>("trailDust");
		sprite = GetNode<Sprite2D>("Sprite2D");

		// Keep dust behind sprite
		trailDust.ZIndex = 0;
		sprite.ZIndex = 1;
	}

	public override void _PhysicsProcess(double delta)
	{
		Vector2 direction = Vector2.Zero;

		if (Input.IsActionPressed("ui_right"))
			direction.X += 1;
		if (Input.IsActionPressed("ui_left"))
			direction.X -= 1;
		if (Input.IsActionPressed("ui_down"))
			direction.Y += 1;
		if (Input.IsActionPressed("ui_up"))
			direction.Y -= 1;

		if (direction != Vector2.Zero)
		{
			direction = direction.Normalized();
			Velocity = direction * Speed;
			trailDust.Emitting = true;

			// Flip sprite when moving left/right
			if (direction.X != 0)
				sprite.FlipH = direction.X < 0;
		}
		else
		{
			Velocity = Vector2.Zero;
			trailDust.Emitting = false;
		}

		MoveAndSlide();
	}
}
